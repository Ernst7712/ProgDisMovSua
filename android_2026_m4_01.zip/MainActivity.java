package com.example.android_2026_m4_01;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "ciclodevida";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate: Creación de la actividad");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart: Inicio de la actividad");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: La actividad fue pausada");
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart: LSe reinicia la actividad");
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume: La actividad es utilizable");
    }


    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop: La actividad ya no es visible");
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: Se termina la actividad");
    }
}
