package com.example.fibonacci1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TextView resultadoF;
    private Button btnSig, btnAnt;

    private int posicionactual = 0;
    private List<Integer> memo = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        resultadoF = findViewById(R.id.resultadoF);
        btnSig = findViewById(R.id.btnSig);
        btnAnt = findViewById(R.id.btnAnt);

        memo.add(0);
        memo.add(1);


        btnSig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                posicionactual++;
                cambioInter();
            }
        });

        btnAnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (posicionactual > 1) {
                    posicionactual--;
                    cambioInter();
                }
            }
        });
    }

    private int secFibonacci(int n) {
        if (n < memo.size()) {

            return memo.get(n);
        }
        for (int i = memo.size(); i <= n; i++) {
            int sigVal = memo.get(i - 1) + memo.get(i - 2);
            memo.add(sigVal);
        }
        return memo.get(n);
    }

    private void cambioInter() {
        int valorF = secFibonacci(posicionactual);
        resultadoF.setText(String.valueOf(valorF));
    }
}