package com.example.myapplication;

public interface IDisplay
{
   String muestraResultado(float res);
   String muestraError(CalculadoraError error);
}
