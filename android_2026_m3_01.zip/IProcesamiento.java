package com.example.myapplication;

public interface IProcesamiento
{
    float suma(float x, float y);
    float resta(float x, float y);
    float multi(float x, float y);
    float div(float x, float y);
}
