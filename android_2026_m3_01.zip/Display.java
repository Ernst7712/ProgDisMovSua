package com.example.myapplication;

import android.util.Log;

public class Display implements IDisplay {

    @Override
    public String muestraResultado(float res) {
        if (Float.isNaN(res)) {
            return muestraError(CalculadoraError.DIV_ZERO);
        }
        Log.d("CalcRes", "Resultado: " + res);
        return "Resultado: " + res;
    }

    @Override
    public String muestraError(CalculadoraError error) {
        String mensaje = "Error: " + error.toString();
        Log.e("CalcRes", mensaje);
        return mensaje;
    }
}
