package com.example.myapplication;

public class Control implements IControl {

    private float x;
    private float y;
    private Operacion operacion;
    private IProcesamiento procesamiento;

    public Control(IProcesamiento procesamiento) {
        this.procesamiento = procesamiento;
    }

    @Override
    public void introduceValorX(float x) {
        this.x = x;
    }

    @Override
    public void introduceValorY(float y) {
        this.y = y;
    }

    @Override
    public void introduceOperacion(Operacion op) {
        this.operacion = op;
    }

    @Override
    public float igual() {
        float resultado = Float.NaN;

        switch (operacion) {
            case SUM:
                resultado = procesamiento.suma(x, y);
                break;
            case RES:
                resultado = procesamiento.resta(x, y);
                break;
            case MUL:
                resultado = procesamiento.multi(x, y);
                break;
            case DIV:
                resultado = procesamiento.div(x, y);
                break;
        }
        return resultado;
    }
}
