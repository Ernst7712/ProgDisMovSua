package com.example.myapplication;

public enum CalculadoraError
{
    DIV_ZERO, MAX_NUMBER, IMAGINARIO
}
