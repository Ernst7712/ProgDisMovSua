package com.example.myapplication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        IProcesamiento procesamiento = new Procesamiento();
        Control control = new Control(procesamiento);
        Display display = new Display();
        Calculadora calc = new Calculadora();

        calc.setControl(control);
        calc.setDisplay(display);
        calc.setProcesamiento(procesamiento);


        control.introduceValorX(100);
        control.introduceValorY(52);
        control.introduceOperacion(Operacion.DIV);

        calc.ejecutar();
    }
}
