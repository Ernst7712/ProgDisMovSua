package com.example.myapplication;

public enum Operacion
{
    SUM, RES, MUL, DIV
}
