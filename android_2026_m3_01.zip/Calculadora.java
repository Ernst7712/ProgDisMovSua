package com.example.myapplication;

public class Calculadora implements ICalculadora {

    private IControl control;
    private IDisplay display;
    private IProcesamiento procesamiento;

    @Override
    public void setControl(IControl control) {
        this.control = control;
    }

    @Override
    public void setDisplay(IDisplay display) {
        this.display = display;
    }

    @Override
    public void setProcesamiento(IProcesamiento procesa) {
        this.procesamiento = procesa;
    }

    public void ejecutar() {
        float resultado = control.igual();
        display.muestraResultado(resultado);
    }
}
