package com.example.myapplication;

public interface ICalculadora
{
    void setControl(IControl control);
    void setDisplay(IDisplay display);
    void setProcesamiento(IProcesamiento procesa);
}
