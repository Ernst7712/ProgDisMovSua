package com.example.myapplication;

public interface IControl
{
    void introduceValorX(float x);
    void introduceValorY(float y);
    void introduceOperacion(Operacion op);
    float igual();
}
